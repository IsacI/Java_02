
public class Letra {
	public static void imprimeLetras(String palavra) {
	    for (int i = 0; i < palavra.length(); i++) {
	        char letra = palavra.charAt(i);
	        System.out.println(letra);
	    }
	}
}
