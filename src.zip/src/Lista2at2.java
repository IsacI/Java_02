
public class Lista2at2 {
	public static int somaArray(int[] array) {
	    int soma = 0;
	    for (int i = 0; i < array.length; i++) {
	        soma += array[i];
	    }
	    return soma;
	}

}
